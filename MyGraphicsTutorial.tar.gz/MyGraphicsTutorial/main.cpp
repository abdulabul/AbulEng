#include <iostream>

#include "gui/MainGame.h"


using namespace std;

int main( int argc, char** argv) {

    MainGame* m=new MainGame();
    m->run();

    return 0;
}