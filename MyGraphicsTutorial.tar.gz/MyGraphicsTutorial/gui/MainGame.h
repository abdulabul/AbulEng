//
// Created by abul on 21/10/16.
//

#ifndef MYGRAPHICSTUTORIAL_MAINGAME_H
#define MYGRAPHICSTUTORIAL_MAINGAME_H

#pragma once

#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <iostream>
#include <vector>
#include "../Bengine/gui/Sprite.h"
#include "../Bengine/gui/GLSProgram.h"
#include "../Bengine/dto/GLTexture.h"
#include "../Bengine/window/Window.h"
#include "../Bengine/gui/Camera2D.h"


enum class GameState{PLAY,EXIT};

class MainGame {

public:
    MainGame();
    ~MainGame();

    void run();


private:

    void initShader();
    void gameLoop();
    void processInput();
    void drawGame();
    void calculateFPS();
    void initSystem();


    eng::Window _window;
    eng::Camera2D _camera;
    int screenWidth;
    int screenHeight;
    GameState gameState;
    float _time;
    float _cameraSpeed;

    float _fps;
    float maxFps;
    float _frameTime;

    std::vector<eng::Sprite*> sprites;
    eng::GLSProgram colorProgram;

};


#endif //MYGRAPHICSTUTORIAL_MAINGAME_H
