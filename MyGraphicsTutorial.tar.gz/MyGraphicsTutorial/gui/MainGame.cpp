//
// Created by abul on 21/10/16.
//

#include "MainGame.h"
#include "../Bengine/window/Aengine.h"


MainGame::MainGame():
        screenWidth(1200),
        screenHeight(600),
        gameState(GameState::PLAY),
        _time(0.0),
        maxFps(60.0f){
    _camera.init(screenWidth,screenHeight);
}

void MainGame::run() {
    initSystem();

//    sprite=new Sprite();
    sprites.push_back(new eng::Sprite);
    sprites.back()->init(0.0f,0.0f,screenWidth/2,screenHeight/2,"../textures/jimmyjump/PNG/enemys/Enemy_Broccoli1.png");

    sprites.push_back(new eng::Sprite);
    sprites.back()->init(screenWidth/2,0.0f,screenWidth/2,screenHeight/2,"../textures/jimmyjump/PNG/enemys/Enemy_Broccoli1.png");
//    _playerTexture=ImageLoader::loadPNG("../textures/jimmyjump/PNG/enemys/Enemy_Broccoli1.png");

    gameLoop();
}
void  MainGame::initSystem(){
    eng::init();

    _window.create("Game Engine",screenWidth,screenHeight,0);

    initShader();
}


void MainGame::initShader() {
    colorProgram.compileShader("../shader/colorShader.vert","../shader/colorShader.frag");
    colorProgram.addAttributes("vertexPosition");
    colorProgram.addAttributes("vertexColor");
    colorProgram.addAttributes("vertexUV");
    colorProgram.linkShader();
}

void MainGame::gameLoop(){

    while (gameState!=GameState::EXIT){
        float startTicks=SDL_GetTicks();

        processInput();
        _time=_time+0.01;

        _camera.update();

        drawGame();

        calculateFPS();

//        print frame count
        static int frameCount=0;
        frameCount++;
        if(frameCount==10){
            std::cout<<_fps<<std::endl;
            frameCount=0;
        }

        float frameTicks=SDL_GetTicks()-startTicks;

        if(1000.0f/maxFps>frameTicks){
            SDL_Delay(1000.0f/maxFps-frameTicks);
        }
    }


}
void MainGame::processInput(){

    SDL_Event evnt;
    const float SCALE_SPEED=0.01f;
    _cameraSpeed=20.0f;

    while (SDL_PollEvent(&evnt)){

        switch (evnt.type){

            case SDL_QUIT:
                gameState=GameState ::EXIT;
                break;
            case SDL_MOUSEMOTION:
//                cout<<evnt.motion.x<<"   "<<evnt.motion.y<<endl;
                break;
            case SDL_KEYDOWN:
                switch (evnt.key.keysym.sym){
                    case SDLK_w:
                        _camera.setPosition(_camera.getPosition()+glm::vec2(0.0f,-_cameraSpeed));
                        break;
                    case SDLK_s:
                        _camera.setPosition(_camera.getPosition()+glm::vec2(0.0f,_cameraSpeed));
                        break;
                    case SDLK_a:
                        _camera.setPosition(_camera.getPosition()+glm::vec2(_cameraSpeed,0.0f));
                        break;
                    case SDLK_d:
                        _camera.setPosition(_camera.getPosition()+glm::vec2(-_cameraSpeed,0.0f));
                        break;
                    case SDLK_q:
                        _camera.setScale(_camera.getScale()+SCALE_SPEED);
                        break;
                    case SDLK_e:
                        _camera.setScale(_camera.getScale()-SCALE_SPEED);
                        break;
                }
                break;
        }
    }
}

void MainGame::drawGame() {

    glClearDepth(1.0);
//    clear the color and depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

//    Tell opengl we want to use color (only needed for immidiate mode)
//    glEnableClientState(GL_COLOR_ARRAY);

//    draw triangle
 /*   glBegin(GL_TRIANGLES);

    glColor3f(0.0f,0.0f,0.0f);
    glVertex2f(-1,-1);
    glVertex2f(-1,0);
    glVertex2f(0,-1);

    glEnd();*/

    colorProgram.use();

    glActiveTexture(GL_TEXTURE0);

//    passing value to uniform of shader mysample
    GLint textureLocation=colorProgram.getUniformLocation("mySample");
    glUniform1i(textureLocation,0);

    //    passing value to uniform of shader time
    GLint timeLocation=colorProgram.getUniformLocation("time");
    glUniform1f(timeLocation,_time);

    //    passing value to uniform of shader P
//    SET CAMERA MATRIX
    GLint pLocation=colorProgram.getUniformLocation("P");
    glm::mat4 cameraMatrix =_camera.getCameraMatrix();
    glUniformMatrix4fv(pLocation,1,GL_FALSE,&(cameraMatrix[0][0]));

    for(int i=0;i<sprites.size();i++){
        sprites[i]->draw();
    }

    glBindTexture(GL_TEXTURE_2D,0);
    colorProgram.unuse();
    _window.swapBuffer();
}

void MainGame::calculateFPS() {

    static const int NUM_SAMPLES=10;
    static float frameTimes[NUM_SAMPLES];
    static int currentFrame=0;

    static float prevTics=SDL_GetTicks();

    float currentTics;
    currentTics=SDL_GetTicks();

    _frameTime=currentTics-prevTics;
    frameTimes[currentFrame%NUM_SAMPLES]=_frameTime;

    prevTics=currentTics;

    int count;

    currentFrame++;
    if(currentFrame < NUM_SAMPLES){
    count=currentFrame;
    } else{
        count=NUM_SAMPLES;
    }

    float frameTimeAverage=0;
    for(int i=0;i<count;i++){
        frameTimeAverage+=frameTimes[i];
    }
    frameTimeAverage/=count;

    if(frameTimeAverage > 0){
        _fps=1000.0f/frameTimeAverage;
    } else{
        _fps=60.0f;
    }
}

MainGame::~MainGame(){

}
