//
// Created by abul on 14/11/16.
//

#include <iostream>
#include "TextureCatch.h"
#include "../gui/ImageLoader.h"
namespace eng {

    GLTexture TextureCatch::getTexture(std::string texturePath) {

//    look the texture
        std::map<std::string, GLTexture>::iterator mit = _textureMap.find(texturePath);

//    check if it is not in the map
        if (mit == _textureMap.end()) {

            GLTexture newTexture = ImageLoader::loadPNG(texturePath);

            std::pair<std::string, GLTexture> newPair(texturePath, newTexture);
            _textureMap.insert(newPair);

            std::cout << "new texture created" << std::endl;
            return newTexture;
        }
        std::cout << "reuse texture from catch" << std::endl;
        return mit->second;

    }
}