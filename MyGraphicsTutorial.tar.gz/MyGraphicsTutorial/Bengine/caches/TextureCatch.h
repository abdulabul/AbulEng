//
// Created by abul on 14/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_TEXTURECATCH_H
#define MYGRAPHICSTUTORIAL_TEXTURECATCH_H


#include <map>
#include <string>
#include "../dto/GLTexture.h"

namespace eng {

    class TextureCatch {
    public:

        GLTexture getTexture(std::string texturePath);

    private:
        std::map<std::string, GLTexture> _textureMap;
    };

}
#endif //MYGRAPHICSTUTORIAL_TEXTURECATCH_H
