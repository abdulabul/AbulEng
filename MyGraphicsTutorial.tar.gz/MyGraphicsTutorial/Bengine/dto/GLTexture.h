//
// Created by abul on 13/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_GLTEXTURE_H
#define MYGRAPHICSTUTORIAL_GLTEXTURE_H

#include "GL/glew.h"
namespace eng {
    struct GLTexture {
        GLuint id;
        int width;
        int height;
    };
}
#endif //MYGRAPHICSTUTORIAL_GLTEXTURE_H
