//
// Created by abul on 13/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_IMAGELOADER_H
#define MYGRAPHICSTUTORIAL_IMAGELOADER_H

#include "../dto/GLTexture.h"
#include <string>
namespace eng {

    class ImageLoader {

    public:
        static GLTexture loadPNG(std::string filePath);

    };

}
#endif //MYGRAPHICSTUTORIAL_IMAGELOADER_H
