//
// Created by abul on 15/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_CAMERA2D_H
#define MYGRAPHICSTUTORIAL_CAMERA2D_H

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace eng {

    class Camera2D {

    public:

        Camera2D();

        ~Camera2D();

        void init(int screenWidth, int screenHeight);

        void update();

//    setter & setter

        const glm::vec2 getPosition() { return _position; }
        void setPosition(const glm::vec2 &_position) { Camera2D::_position = _position; _needsChange=true;}

        const glm::mat4 getCameraMatrix() { return _cameraMatrix; }
//    void Camera2D::setCameraMatrix(const glm::mat4 &_cameraMatrix) {Camera2D::_cameraMatrix = _cameraMatrix;}

        float getScale() { return _scale; }
        void setScale(float _scale) { Camera2D::_scale = _scale;_needsChange=true; }

    private:
        int _screenWidth, _screenHeight;
        bool _needsChange;
        float _scale;
        glm::vec2 _position;
        glm::mat4 _orthoMatrix;
        glm::mat4 _cameraMatrix;

    };

}
#endif //MYGRAPHICSTUTORIAL_CAMERA2D_H
