//
// Created by abul on 12/11/16.
//

#include <fstream>
#include <vector>
#include "GLSProgram.h"
#include "../utils/Utils.h"

namespace eng {

    GLSProgram::GLSProgram() : _numAttribute(0), _programID(0), _vertexShaderID(0), _fragmentShaderID(0) {

    }

    GLSProgram::~GLSProgram() {

    }

    void GLSProgram::compileShader(const std::string &vertexShaderFilePath, const std::string &fragmentShaderFilePath) {

//    create a program
        _programID = glCreateProgram();

        /*create vertex shader*/
        _vertexShaderID = glCreateShader(GL_VERTEX_SHADER);
        if (_vertexShaderID == 0) {
            fatalError("vertex shader fail to be created");
        }

        /*create fragment shader*/
        _fragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);
        if (_fragmentShaderID == 0) {
            fatalError("fragment shader fail to be created");
        }

        compleShader(vertexShaderFilePath, _vertexShaderID);
        compleShader(fragmentShaderFilePath, _fragmentShaderID);

    }

    void GLSProgram::compleShader(const std::string filePath, GLuint id) {
        std::ifstream vertexFile(filePath);
        if (vertexFile.fail()) {
            fatalError("fail to open " + filePath);
        }

        std::string fileContent = "";
        std::string line;

        while (std::getline(vertexFile, line)) {
            fileContent += line + "\n";
        }
        vertexFile.close();

        const char *contentPtr = fileContent.c_str();
        glShaderSource(id, 1, &contentPtr, nullptr);

        glCompileShader(id);

        GLint success = 0;
        glGetShaderiv(id, GL_COMPILE_STATUS, &success);

        if (success == false) {
            GLint maxLen = 0;
            glGetShaderiv(id, GL_INFO_LOG_LENGTH, &maxLen);
            std::vector<char> errorLog(maxLen);

            glGetShaderInfoLog(id, maxLen, &maxLen, &errorLog[0]);
            glDeleteShader(id);

            std::printf("%s\n", &(errorLog[0]));
            fatalError("shader " + filePath + " failed to compile");
        }
    }

    void GLSProgram::linkShader() {

//    attaching our shader with our program
        glAttachShader(_programID, _vertexShaderID);
        glAttachShader(_programID, _fragmentShaderID);

// linking our program
        glLinkProgram(_programID);

        GLint isLInked = 0;
        glGetProgramiv(_programID, GL_LINK_STATUS, (int *) &isLInked);
        if (isLInked == false) {
            GLint maxLen = 0;
            glGetProgramiv(_programID, GL_INFO_LOG_LENGTH, &maxLen);
            std::vector<char> errorLog(maxLen);

            glGetProgramInfoLog(_programID, maxLen, &maxLen, &errorLog[0]);
            glDeleteProgram(_programID);

            glDeleteShader(_vertexShaderID);
            glDeleteShader(_fragmentShaderID);

            std::printf("%s\n", &(errorLog[0]));
            fatalError("program linked failed to compile");
        }

//    Always detach the shader id agter successfull kink
        glDetachShader(_programID, _vertexShaderID);
        glDetachShader(_programID, _fragmentShaderID);
        glDeleteShader(_vertexShaderID);
        glDeleteShader(_fragmentShaderID);
    }

    void GLSProgram::addAttributes(const std::string attribName) {
        glBindAttribLocation(_programID, _numAttribute++, attribName.c_str());
    }

    GLint GLSProgram::getUniformLocation(const std::string &uniformName) {
        GLint location = glGetUniformLocation(_programID, uniformName.c_str());
        if (location == GL_INVALID_INDEX) {
            fatalError("Uniform " + uniformName + " not found in shader");
        }
        return location;
    }

    void GLSProgram::use() {
        glUseProgram(_programID);
        for (int i = 0; i < _numAttribute; i++) {
            glEnableVertexAttribArray(i);
        }
    }

    void GLSProgram::unuse() {
        glUseProgram(0);
        for (int i = 0; i < _numAttribute; i++) {
            glDisableVertexAttribArray(i);
        }
    }
}