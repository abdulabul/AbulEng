//
// Created by abul on 12/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_GLSPROGRAM_H
#define MYGRAPHICSTUTORIAL_GLSPROGRAM_H

#include <iostream>
#include "GL/glew.h"

namespace eng {

    class GLSProgram {

    public:
        GLSProgram();

        ~GLSProgram();

        void compileShader(const std::string &vertexShaderFilePath, const std::string &fragmentShaderFilePath);

        void linkShader();

        void addAttributes(const std::string attribName);

        GLint getUniformLocation(const std::string &uniformName);

        void use();

        void unuse();

    private:

        void compleShader(const std::string filePath, GLuint id);

        int _numAttribute;
        GLuint _programID;
        GLuint _vertexShaderID;
        GLuint _fragmentShaderID;

    };

}
#endif //MYGRAPHICSTUTORIAL_GLSPROGRAM_H
