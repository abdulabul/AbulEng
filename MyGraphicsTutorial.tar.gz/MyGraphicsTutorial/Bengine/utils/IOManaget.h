//
// Created by abul on 13/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_IOMANAGET_H
#define MYGRAPHICSTUTORIAL_IOMANAGET_H

#include <iostream>
#include <vector>
namespace eng {
    class IOManaget {

    public:
        static bool readFileBuffer(std::string filePath, std::vector<unsigned char> &buffer);

    };
}

#endif //MYGRAPHICSTUTORIAL_IOMANAGET_H
