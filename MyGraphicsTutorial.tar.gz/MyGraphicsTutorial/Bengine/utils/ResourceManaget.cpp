//
// Created by abul on 14/11/16.
//

#include "ResourceManaget.h"
namespace eng {
    TextureCatch ResourceManaget::_textureCache;

    GLTexture ResourceManaget::getTexture(std::string texturePath) {
        return _textureCache.getTexture(texturePath);
    }

}