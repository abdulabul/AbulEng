//
// Created by abul on 14/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_RESOURCEMANAGET_H
#define MYGRAPHICSTUTORIAL_RESOURCEMANAGET_H


#include "../caches/TextureCatch.h"
namespace eng {
    class ResourceManaget {

    public:
        static GLTexture getTexture(std::string texturePath);

    private:
        static TextureCatch _textureCache;

    };
}

#endif //MYGRAPHICSTUTORIAL_RESOURCEMANAGET_H
