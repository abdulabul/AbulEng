//
// Created by abul on 12/11/16.
//

#include "Utils.h"
#include <iostream>
#include "SDL/SDL.h"
#include <cstdlib>
namespace eng {
    void fatalError(std::string errorString) {

        std::cout << errorString << std::endl;
        std::cout << "Enter Any Key To Exit" << std::endl;
        int tmp;
        std::cin >> tmp;
        SDL_Quit();
        exit(69);
    }
}