//
// Created by abul on 12/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_UTILS_H
#define MYGRAPHICSTUTORIAL_UTILS_H

#include <string>
namespace eng {
    extern void fatalError(std::string errorString);
}

#endif //MYGRAPHICSTUTORIAL_UTILS_H
