//
// Created by abul on 14/11/16.
//

#include <iostream>
#include "Window.h"
#include "../utils/Utils.h"

namespace eng {

    int Window::create(std::string windowName, int screenWidth, int screenHeight, unsigned int currentFlag) {

        Uint32 flag = SDL_WINDOW_OPENGL;

        if (currentFlag & INVISIBLE) {
            flag |= SDL_WINDOW_HIDDEN;
        }
        if (currentFlag & FULLSCREEN) {
            flag |= SDL_WINDOW_FULLSCREEN_DESKTOP;
        }
        if (currentFlag & BORDERLESS) {
            flag |= SDL_WINDOW_BORDERLESS;
        }

//    Open an sdl window
        sdlWindow = SDL_CreateWindow(windowName.c_str(),
                                     SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                     screenWidth, screenHeight, flag);

//    setup our opengl context
        SDL_GLContext glContext = SDL_GL_CreateContext(sdlWindow);
        if (glContext == nullptr) {
            fatalError("context not initialized");
        }

//    setup glew (optional but recommmended)
        GLenum error = glewInit();
        if (error != GLEW_OK) {
            fatalError("glew not initialized");
        }

//    opengl version
        std::printf("***** opengl version %s *****\n", glGetString(GL_VERSION));

//    set the background color to blue
        glClearColor(0.0f, 0.0f, 1.0f, 0.0f);

//    set vsync (uses the monitor refresh rate to refresh the frame)
        SDL_GL_SetSwapInterval(1);

        return 0;
    }

    void Window::swapBuffer() {
        //    swap the buffer and draw every thing to screen
        SDL_GL_SwapWindow(sdlWindow);
    }
}