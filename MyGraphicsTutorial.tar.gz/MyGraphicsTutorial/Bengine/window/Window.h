//
// Created by abul on 14/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_WINDOW_H
#define MYGRAPHICSTUTORIAL_WINDOW_H

#include <string>
#include <SDL2/SDL.h>
#include <GL/glew.h>

namespace eng {

    enum WindowFlag {
        INVISIBLE = 0x1, FULLSCREEN = 0x2, BORDERLESS = 0x4
    };

    class Window {

    public:
        int create(std::string windowName, int screenWidth, int screenHeight, unsigned int currentFlag);

        void swapBuffer();

        int getScreenWidth() { return screenWidth; }

        int getScreenHeight() { return screenHeight; }

    private:
        SDL_Window *sdlWindow;
        int screenWidth, screenHeight;
    };

}
#endif //MYGRAPHICSTUTORIAL_WINDOW_H
