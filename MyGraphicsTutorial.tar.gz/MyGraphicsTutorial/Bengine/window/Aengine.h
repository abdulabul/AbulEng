//
// Created by abul on 14/11/16.
//

#ifndef MYGRAPHICSTUTORIAL_AENGINE_H
#define MYGRAPHICSTUTORIAL_AENGINE_H

namespace eng {

     int init();

}
#endif //MYGRAPHICSTUTORIAL_AENGINE_H
