//
// Created by abul on 14/11/16.
//

#include "Aengine.h"
#include <SDL2/SDL.h>
namespace eng {

    int init() {
//    Initialize sdl
        SDL_Init(SDL_INIT_EVERYTHING);
//    Tell sdl that we want a double buffer window so that we
//    don,t get flirking window
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

        return 0;
    }

}